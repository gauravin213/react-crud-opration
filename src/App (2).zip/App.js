import React from "react";
import axios from "axios";
import "./App.css";
import "../node_modules/bootstrap/dist/css/bootstrap.css";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

import Home from "./components/pages/Home";
import About from "./components/pages/About";
import Contact from "./components/pages/Contact";
import Navbar from "./components/Layout/Navbar";
import NotFound from "./components/pages/NotFound";
import AddUser from "./components/users/AddUser";
import EditUser from "./components/users/EditUser";
import User from "./components/users/User";
import UserLogin from "./components/pages/UserLogin";
import Protected from "./components/pages/Protected";

const pp_token = localStorage.getItem("auth_success_token");

let isLogedIn = 0;

/*
 * Working method 1
 */
axios.interceptors.request.use(
  function (config) {
    config.headers.authorization = `Bearer ${pp_token}`;
    return config;
  },
  function (error) {
    return Promise.reject(error);
  }
);
/*
 * Working method 1
 */

const onAuthHandle = (user) => {
  /*const result = axios.post("http://127.0.0.1:8000/api/login", user);
  result.then((result) => {
    const auth_success_token = result.data.success.token;
    console.log(auth_success_token);
    localStorage.setItem("auth_success_token", auth_success_token);
    console.log("-----------------------------");
    console.log(result.data);
    console.log("-----------------------------");
    //history.push("/");
  });
  
  */

  isLogedIn++;
  console.log(isLogedIn);
};

function App() {
  return (
    <div>
      <Router>
        <div className="App">
          <Navbar onReset="ppppppp" isLogedIn={isLogedIn} />
          <Switch>
            <Route exact path="/">
              <Protected component={Home} />
            </Route>
            <Route exact path="/about" component={About} />
            <Route exact path="/contact" component={Contact} />
            <Route exact path="/users/add" component={AddUser} />
            <Route exact path="/users/edit/:id" component={EditUser} />
            <Route exact path="/login" component={UserLogin}>
              <UserLogin onAuthHandle={onAuthHandle} />
            </Route>
            <Route exact path="/users/:id" component={User} />
            <Route component={NotFound} />
          </Switch>
        </div>
      </Router>
    </div>
  );
}

export default App;
